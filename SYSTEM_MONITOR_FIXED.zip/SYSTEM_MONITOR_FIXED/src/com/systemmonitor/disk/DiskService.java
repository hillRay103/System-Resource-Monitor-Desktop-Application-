package com.systemmonitor.disk;

import java.io.File;
import com.systemmonitor.utils.SettingsService;

public class DiskService {

    private File disk;

    public DiskService() {
        
        disk = new File("/");
    }

    
    public long getTotalDiskSpace() {
        return disk.getTotalSpace();
    }

    
    public long getFreeDiskSpace() {
        return disk.getFreeSpace();
    }

    
    public long getUsedDiskSpace() {
        return getTotalDiskSpace() - getFreeDiskSpace();
    }

    
    public double bytesToGB(long bytes) {
        return bytes / (1024.0 * 1024.0 * 1024.0);
    }

    
    public boolean isDiskLow() {
        double freeGB = bytesToGB(getFreeDiskSpace());
        
        double thresholdGB = SettingsService.getDiskAlertPercent(); 
        return freeGB < thresholdGB;
    }

   
    public double getDiskThresholdGB() {
        return SettingsService.getDiskAlertPercent();
    }
}
