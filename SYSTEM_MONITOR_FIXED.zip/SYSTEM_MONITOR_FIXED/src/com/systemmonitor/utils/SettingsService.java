package com.systemmonitor.utils;

import java.io.*;
import java.util.Properties;

public class SettingsService {

    private static final String FILE = "settings.properties";
    private static final Properties props = new Properties();

    // defaults
    static {
        props.setProperty("refreshIntervalMs", "1000");
        props.setProperty("cpuAlertPercent", "85");
        props.setProperty("memoryAlertPercent", "85");
        props.setProperty("diskAlertPercent", "90");
        load();
    }

    public static synchronized void load() {
        try (InputStream in = new FileInputStream(FILE)) {
            props.load(in);
        } catch (Exception ignored) { /* use defaults */ }
    }

    public static synchronized void save() {
        try (OutputStream out = new FileOutputStream(FILE)) {
            props.store(out, "System Monitor Settings");
        } catch (Exception e) {
            LoggerService.log("Failed to save settings: " + e.getMessage());
        }
    }

    public static int getRefreshIntervalMs() {
        return Integer.parseInt(props.getProperty("refreshIntervalMs", "1000"));
    }

    public static void setRefreshIntervalMs(int ms) {
        props.setProperty("refreshIntervalMs", Integer.toString(Math.max(200, ms)));
    }

    public static int getCpuAlertPercent() {
        return Integer.parseInt(props.getProperty("cpuAlertPercent", "85"));
    }

    public static void setCpuAlertPercent(int v) {
        props.setProperty("cpuAlertPercent", Integer.toString(v));
    }

    public static int getMemoryAlertPercent() {
        return Integer.parseInt(props.getProperty("memoryAlertPercent", "85"));
    }

    public static void setMemoryAlertPercent(int v) {
        props.setProperty("memoryAlertPercent", Integer.toString(v));
    }

    public static int getDiskAlertPercent() {
        return Integer.parseInt(props.getProperty("diskAlertPercent", "90"));
    }

    public static void setDiskAlertPercent(int v) {
        props.setProperty("diskAlertPercent", Integer.toString(v));
    }
}