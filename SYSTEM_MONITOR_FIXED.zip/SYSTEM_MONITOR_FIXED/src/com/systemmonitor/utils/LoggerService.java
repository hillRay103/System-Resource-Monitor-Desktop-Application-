package com.systemmonitor.utils;

import java.io.*;
import java.time.LocalDateTime;
import java.nio.file.Files;
import java.nio.file.Paths;

public class LoggerService {

    private static final String LOG_FILE = "system_logs.txt";

    // Save a log message with timestamp
    public static synchronized void log(String message) {
        try (FileWriter writer = new FileWriter(LOG_FILE, true)) {
            writer.write(LocalDateTime.now() + " - " + message + "\n");
        } catch (IOException e) {
            System.out.println("Error writing to log file: " + e.getMessage());
        }
    }

    // Read the entire log file (returns empty string if missing)
    public static synchronized String readLogs() {
        try {
            if (!Files.exists(Paths.get(LOG_FILE))) return "";
            return Files.readString(Paths.get(LOG_FILE));
        } catch (IOException e) {
            return "Error reading logs: " + e.getMessage();
        }
    }

    // Clear the log file
    public static synchronized void clearLogs() {
        try (FileWriter writer = new FileWriter(LOG_FILE, false)) {
            writer.write("");
        } catch (IOException e) {
            System.out.println("Error clearing log file: " + e.getMessage());
        }
    }
}