package com.systemmonitor.utils;

import java.lang.management.ManagementFactory;
import com.sun.management.OperatingSystemMXBean;
import java.text.DecimalFormat;

public class SystemUtils {

    private static final OperatingSystemMXBean osBean =
            (OperatingSystemMXBean) ManagementFactory.getOperatingSystemMXBean();

    // -------- CPU (Modern) --------
    public static double getCpuUsage() {
        double value = osBean.getCpuLoad();
        return (value < 0) ? 0 : value * 100;
    }

    // -------- MEMORY (Modern) --------
    public static long getTotalMemory() {
        return osBean.getTotalMemorySize();
    }

    public static long getFreeMemory() {
        return osBean.getFreeMemorySize();
    }

    // -------- DISK --------
    public static long getDiskTotal(String path) {
        return new java.io.File(path).getTotalSpace();
    }

    public static long getDiskFree(String path) {
        return new java.io.File(path).getFreeSpace();
    }

    // Format bytes → human readable (GB, MB)
    public static String formatBytes(long bytes) {
        double gb = bytes / (1024.0 * 1024.0 * 1024.0);
        if (gb >= 1.0) {
            return new DecimalFormat("#0.0").format(gb) + " GB";
        }
        double mb = bytes / (1024.0 * 1024.0);
        return new DecimalFormat("#0.0").format(mb) + " MB";
    }

    // OS helpers
    public static boolean isWindows() {
        String os = System.getProperty("os.name");
        return os != null && os.toLowerCase().contains("windows");
    }
}