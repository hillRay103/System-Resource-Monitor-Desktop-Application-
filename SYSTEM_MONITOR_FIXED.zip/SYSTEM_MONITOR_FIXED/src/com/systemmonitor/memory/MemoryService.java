package com.systemmonitor.memory;

import com.sun.management.OperatingSystemMXBean;
import java.lang.management.ManagementFactory;
import com.systemmonitor.utils.SettingsService;

public class MemoryService {

    private OperatingSystemMXBean osBean;

    public MemoryService() {
        osBean = (OperatingSystemMXBean) ManagementFactory.getOperatingSystemMXBean();
    }

   
    public long getTotalMemory() {
        return osBean.getTotalMemorySize();
    }

    
    public long getFreeMemory() {
        return osBean.getFreeMemorySize();
    }

    
    public long getUsedMemory() {
        return getTotalMemory() - getFreeMemory();
    }


    public double getFreeMemoryPercentage() {
        if (getTotalMemory() == 0) return 0;
        return ((double) getFreeMemory() / getTotalMemory()) * 100.0;
    }

    
    public boolean isMemoryLow() {
        double freePercent = getFreeMemoryPercentage();
        double thresholdPercent = SettingsService.getMemoryAlertPercent();
        return freePercent < thresholdPercent;
    }


    public double getMemoryThresholdPercentage() {
        return SettingsService.getMemoryAlertPercent();
    }


    public double bytesToGB(long bytes) {
        return bytes / (1024.0 * 1024.0 * 1024.0);
    }

    
    public long getMemory() {
        return getUsedMemory();
    }
}
