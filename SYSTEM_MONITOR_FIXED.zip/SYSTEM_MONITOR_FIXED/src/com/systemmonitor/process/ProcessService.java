package com.systemmonitor.process;

import com.systemmonitor.memory.MemoryService;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.*;

/**
 * Collects process information. On Windows, uses `tasklist` to get Image Name and memory usage.
 * Also keeps previous CPU times to compute CPU% between samples.
 */
public class ProcessService {

    private final Map<Long, Long> previousCpuTimes = new HashMap<>();
    private long lastSampleTime = 0;
    private final int processors = Runtime.getRuntime().availableProcessors();
    private final MemoryService memoryService = new MemoryService();

    public List<ProcessInfo> getRunningProcesses() {
        Map<Long, String> nameMap = new HashMap<>();
        Map<Long, Long> memoryMap = new HashMap<>();

        if (isWindows()) {
            populateFromTasklist(nameMap, memoryMap);
        }

        List<ProcessInfo> list = new ArrayList<>();
        long currentTime = System.currentTimeMillis();
        long elapsed = lastSampleTime == 0 ? 0 : (currentTime - lastSampleTime);

        ProcessHandle.allProcesses().forEach(p -> {
            try {
                long pid = p.pid();

                // Prefer tasklist mapping, else try command() / commandLine()
                String name = nameMap.get(pid);
                if (name == null) {
                    name = p.info().command().map(cmd -> {
                        try { return new java.io.File(cmd).getName(); } catch (Exception ex) { return cmd; }
                    }).orElseGet(() -> p.info().commandLine().orElse("Unknown"));
                }

                long cpuTime = p.info().totalCpuDuration().map(d -> d.toMillis()).orElse(0L);

                double cpuPercent = 0.0;
                if (elapsed > 0) {
                    long prev = previousCpuTimes.getOrDefault(pid, 0L);
                    long deltaCpu = cpuTime - prev;
                    cpuPercent = (deltaCpu * 100.0) / (elapsed * Math.max(1, processors));
                    if (cpuPercent < 0) cpuPercent = 0.0;
                }
                previousCpuTimes.put(pid, cpuTime);

                long memorySize = memoryMap.getOrDefault(pid, 0L);
                double memoryPercent = 0.0;
                long totalMem = memoryService.getTotalMemory();
                if (totalMem > 0 && memorySize > 0) {
                    memoryPercent = (memorySize * 100.0) / (double) totalMem;
                }

                ProcessInfo info = new ProcessInfo(pid, name, cpuTime, memorySize, cpuPercent, memoryPercent);
                list.add(info);

            } catch (Throwable e) {
                // skip inaccessible processes
            }
        });

        lastSampleTime = currentTime;
        return list;
    }

    public List<ProcessInfo> getTopCpuProcesses(int limit) {
        return getRunningProcesses().stream()
                .sorted(Comparator.comparingDouble(ProcessInfo::getCpuPercent).reversed())
                .limit(limit)
                .toList();
    }

    public List<ProcessInfo> getProcesses() {
        return getRunningProcesses();
    }

    private boolean isWindows() {
        String os = System.getProperty("os.name");
        return os != null && os.toLowerCase().contains("windows");
    }

    /**
     * Parse `tasklist /FO CSV /NH`. Example CSV line:
     * "chrome.exe","1234","Console","1","120,000 K"
     */
    private void populateFromTasklist(Map<Long, String> nameMap, Map<Long, Long> memoryMap) {
        try {
            Process p = new ProcessBuilder("tasklist", "/FO", "CSV", "/NH").redirectErrorStream(true).start();
            try (BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()))) {
                String line;
                while ((line = r.readLine()) != null) {
                    String[] cols = splitCsvLine(line);
                    if (cols.length >= 2) {
                        String imageName = cols[0].replaceAll("^\"|\"$", "").trim();
                        String pidStr = cols[1].replaceAll("^\"|\"$", "").trim();
                        long pid = 0L;
                        try {
                            pid = Long.parseLong(pidStr);
                        } catch (NumberFormatException ignored) {}
                        if (pid > 0) {
                            nameMap.put(pid, imageName);
                        }
                        // Mem usage is often column index 4 (5th column) - parse digits robustly
                        if (cols.length >= 5) {
                            String memStr = cols[4].replaceAll("[^0-9]", "");
                            if (!memStr.isEmpty()) {
                                try {
                                    long kb = Long.parseLong(memStr); // tasklist mem typically in KB
                                    memoryMap.put(pid, kb * 1024L);
                                } catch (NumberFormatException ignored) {}
                            }
                        }
                    }
                }
            }
        } catch (Exception ignored) {
            // best-effort only
        }
    }

    private String[] splitCsvLine(String line) {
        List<String> parts = new ArrayList<>();
        StringBuilder sb = new StringBuilder();
        boolean inQ = false;
        for (int i = 0; i < line.length(); i++) {
            char c = line.charAt(i);
            if (c == '"') {
                inQ = !inQ;
            } else if (c == ',' && !inQ) {
                parts.add(sb.toString());
                sb.setLength(0);
            } else {
                sb.append(c);
            }
        }
        parts.add(sb.toString());
        return parts.toArray(new String[0]);
    }
}
