package com.systemmonitor.process;

public class ProcessInfo {

    private long pid;
    private String name;
    private long cpuTime;
    private long memorySize;
    private double cpuPercent;
    private double memoryPercent;

    public ProcessInfo(long pid, String name, long cpuTime, long memorySize) {
        this(pid, name, cpuTime, memorySize, 0.0, 0.0);
    }

    public ProcessInfo(long pid, String name, long cpuTime, long memorySize,
                       double cpuPercent, double memoryPercent) {
        this.pid = pid;
        this.name = name;
        this.cpuTime = cpuTime;
        this.memorySize = memorySize;
        this.cpuPercent = cpuPercent;
        this.memoryPercent = memoryPercent;
    }

    public long getPid() {
        return pid;
    }

    public String getName() {
        return name;
    }

    public long getCpuTime() {
        return cpuTime;
    }

    public long getMemorySize() {
        return memorySize;
    }

    public double getCpuPercent() {
        return cpuPercent;
    }

    public double getMemoryPercent() {
        return memoryPercent;
    }

    public void setCpuPercent(double cpuPercent) {
        this.cpuPercent = cpuPercent;
    }

    public void setMemoryPercent(double memoryPercent) {
        this.memoryPercent = memoryPercent;
    }
}