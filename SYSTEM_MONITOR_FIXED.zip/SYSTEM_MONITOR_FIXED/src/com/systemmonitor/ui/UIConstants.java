package com.systemmonitor.ui;

import java.awt.*;

public class UIConstants {
    // Colors
    public static final Color BG = new Color(0x1E1E1E);           // main background
    public static final Color SIDEBAR_BG = new Color(0x2A0B2A);   // deep purple
    public static final Color CARD_BG = new Color(0x272727);
    public static final Color ACCENT = new Color(0x8A2BE2);       // primary purple
    public static final Color ACCENT_HOVER = new Color(0x9D4BFF);
    public static final Color TEXT = new Color(0xEDEDED);
    public static final Color MUTED_TEXT = new Color(0xC6BEEA);

    // Fonts
    public static final Font H1 = new Font("Segoe UI", Font.BOLD, 22);
    public static final Font H2 = new Font("Segoe UI", Font.BOLD, 16);
    public static final Font BODY = new Font("Segoe UI", Font.PLAIN, 14);
    public static final Font MONO = new Font("Consolas", Font.PLAIN, 13);

    // Dimensions
    public static final int SIDEBAR_WIDTH = 180;
    public static final int HEADER_HEIGHT = 66;
}
