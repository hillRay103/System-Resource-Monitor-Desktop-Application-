package com.systemmonitor.ui;

import com.systemmonitor.utils.LoggerService;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Timer;
import java.util.TimerTask;

/**
 * AlertsUI — displays system alerts in a styled list.
 *
 * BUG FIXES applied:
 * 1. Red warning icon on Alerts sidebar button was set every update tick
 *    even when there were no alerts, causing a permanent red icon conflict.
 *    Fixed: icon is only set when there ARE alerts, and cleared on clearAll().
 *
 * 2. showPopup() used a blocking JOptionPane inside invokeLater, which froze
 *    the update timer.  Replaced with a lightweight non-blocking toast window
 *    that appears in the bottom-right corner (like a real OS notification)
 *    and auto-dismisses after 4 seconds.
 *
 * 3. addSuggestion() was prepending "⚠ " to a message that already had "⚠ "
 *    in the caller.  Fixed: caller passes clean text; this method adds the prefix.
 */
public class AlertsUI extends JPanel {

    private DefaultListModel<String> alertsModel;
    private JList<String> alertsList;
    private JButton alertsTabButton;
    private Timer autoClearTimer;

    // track whether the red dot is currently shown
    private boolean redDotShown = false;

    public AlertsUI(JButton alertsTabButton) {
        this.alertsTabButton = alertsTabButton;
        setLayout(new BorderLayout());
        setBackground(Color.BLACK);
        initHeader();
        initBody();
    }

    // ── HEADER ────────────────────────────────────────────────────────────
    private void initHeader() {
        JPanel header = new JPanel(new BorderLayout());
        header.setPreferredSize(new Dimension(0, 70));
        header.setBackground(Color.BLACK);

        JLabel title = new JLabel("System Alerts");
        title.setForeground(new Color(180, 150, 255));
        title.setFont(new Font("Segoe UI", Font.BOLD, 26));
        title.setBorder(BorderFactory.createEmptyBorder(0, 20, 0, 0));

        JButton clearBtn = new JButton("Clear All");
        styleButton(clearBtn);
        clearBtn.addActionListener(e -> clearAll());

        header.add(title, BorderLayout.WEST);
        header.add(clearBtn, BorderLayout.EAST);
        add(header, BorderLayout.NORTH);
    }

    // ── BODY ──────────────────────────────────────────────────────────────
    private void initBody() {
        JPanel body = new JPanel(new BorderLayout());
        body.setBackground(Color.BLACK);
        body.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        alertsModel = new DefaultListModel<>();
        alertsList = new JList<>(alertsModel);
        alertsList.setBackground(new Color(30, 30, 30));
        alertsList.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        alertsList.setBorder(BorderFactory.createLineBorder(new Color(120, 50, 255)));

        alertsList.setCellRenderer(new DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(JList<?> list, Object value,
                    int index, boolean isSelected, boolean cellHasFocus) {
                JLabel label = (JLabel) super.getListCellRendererComponent(
                        list, value, index, false, false);
                String text = value.toString();
                if (text.startsWith("❗") || text.toLowerCase().contains("critical")) {
                    label.setForeground(Color.RED);
                } else if (text.startsWith("⚠")) {
                    label.setForeground(new Color(255, 215, 0));
                } else {
                    label.setForeground(new Color(0, 200, 0));
                }
                label.setBackground(Color.BLACK);
                label.setOpaque(true);
                return label;
            }
        });

        JScrollPane scroll = new JScrollPane(alertsList);
        scroll.setBorder(BorderFactory.createLineBorder(new Color(120, 50, 255)));
        body.add(scroll, BorderLayout.CENTER);
        add(body, BorderLayout.CENTER);
    }

    // ── STYLE ─────────────────────────────────────────────────────────────
    private void styleButton(JButton btn) {
        btn.setBackground(new Color(120, 70, 180));
        btn.setForeground(Color.WHITE);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 16));
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createEmptyBorder(8, 20, 8, 20));
    }

    // ── PUBLIC API ────────────────────────────────────────────────────────

    /**
     * Add a critical alert and show a desktop-style toast notification.
     */
    public void addAlert(String message, boolean critical) {
        if (message == null || message.isEmpty()) return;
        SwingUtilities.invokeLater(() -> {
            alertsModel.addElement(message);
            alertsList.ensureIndexIsVisible(alertsModel.size() - 1);
            setTabRedDot();
            LoggerService.log(message);
            if (critical) showToastNotification(message);
            scheduleAutoClear(message, 60000);
        });
    }

    /**
     * Add a suggestion (yellow warning, no popup).
     * Do NOT pass a message that already has "⚠ " prefix — this method adds it.
     */
    public void addSuggestion(String message) {
        if (message == null || message.isEmpty()) return;
        // Strip accidental double prefix from caller
        String clean = message.startsWith("⚠ ") ? message : "⚠ " + message;
        SwingUtilities.invokeLater(() -> {
            alertsModel.addElement(clean);
            alertsList.ensureIndexIsVisible(alertsModel.size() - 1);
            setTabRedDot();
            scheduleAutoClear(clean, 60000);
        });
    }

    // ── PRIVATE HELPERS ───────────────────────────────────────────────────

    /**
     * BUG FIX: Only set the red dot icon once; do not reset it every tick.
     * Previously it was called unconditionally in every addAlert(), even when
     * there were no new alerts, causing the icon to flicker and conflict.
     */
    private void setTabRedDot() {
        if (alertsTabButton == null || redDotShown) return;
        // Use the warning icon if available, otherwise draw a red circle
        ImageIcon icon = IconLoader.load("warning.png", 14);
        if (icon == null) {
            icon = makeDotIcon(14);
        }
        alertsTabButton.setIcon(icon);
        redDotShown = true;
    }

    private void resetTabIcon() {
        if (alertsTabButton != null) {
            alertsTabButton.setIcon(null);
        }
        redDotShown = false;
    }

    /** Create a plain red circle icon as a fallback dot indicator. */
    private ImageIcon makeDotIcon(int size) {
        java.awt.image.BufferedImage img =
                new java.awt.image.BufferedImage(size, size,
                        java.awt.image.BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = img.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setColor(Color.RED);
        g.fillOval(0, 0, size, size);
        g.dispose();
        return new ImageIcon(img);
    }

    /**
     * BUG FIX: Replace blocking JOptionPane with a lightweight, non-blocking
     * toast window that appears in the bottom-right corner of the screen,
     * exactly like a real OS desktop notification.  It auto-dismisses after
     * 4 seconds.  Clicking it dismisses immediately.
     */
    private void showToastNotification(String message) {
        SwingUtilities.invokeLater(() -> {
            // Find screen bounds
            GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
            GraphicsDevice gd = ge.getDefaultScreenDevice();
            Rectangle screen = gd.getDefaultConfiguration().getBounds();

            // Build toast window
            JWindow toast = new JWindow();
            toast.setAlwaysOnTop(true);

            JPanel panel = new JPanel(new BorderLayout(10, 8));
            panel.setBackground(new Color(40, 10, 50));
            panel.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(new Color(180, 60, 255), 2),
                    BorderFactory.createEmptyBorder(12, 16, 12, 16)));

            // Icon
            ImageIcon warnIcon = IconLoader.load("warning.png", 24);
            if (warnIcon != null) {
                panel.add(new JLabel(warnIcon), BorderLayout.WEST);
            }

            // Text block
            JPanel textPanel = new JPanel();
            textPanel.setOpaque(false);
            textPanel.setLayout(new BoxLayout(textPanel, BoxLayout.Y_AXIS));

            JLabel titleLabel = new JLabel("System Alert");
            titleLabel.setForeground(new Color(220, 150, 255));
            titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 13));

            // Wrap long messages
            String wrapped = "<html><body style='width:220px'>" + message + "</body></html>";
            JLabel msgLabel = new JLabel(wrapped);
            msgLabel.setForeground(Color.WHITE);
            msgLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));

            textPanel.add(titleLabel);
            textPanel.add(Box.createVerticalStrut(4));
            textPanel.add(msgLabel);
            panel.add(textPanel, BorderLayout.CENTER);

            // Close button
            JButton close = new JButton("✕");
            close.setForeground(new Color(180, 180, 180));
            close.setBackground(new Color(40, 10, 50));
            close.setBorderPainted(false);
            close.setFocusPainted(false);
            close.setFont(new Font("Segoe UI", Font.PLAIN, 12));
            close.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            close.addActionListener(e -> toast.dispose());
            panel.add(close, BorderLayout.NORTH);

            toast.getContentPane().add(panel);
            toast.pack();

            // Position: bottom-right corner, 20px from edge
            int x = screen.x + screen.width  - toast.getWidth()  - 20;
            int y = screen.y + screen.height - toast.getHeight() - 50;
            toast.setLocation(x, y);

            // Click anywhere to dismiss
            panel.addMouseListener(new MouseAdapter() {
                @Override public void mouseClicked(MouseEvent e) { toast.dispose(); }
            });

            toast.setVisible(true);
            LoggerService.log("Toast shown: " + message);

            // Auto-dismiss after 4 seconds
            Timer dismissTimer = new Timer(true);
            dismissTimer.schedule(new TimerTask() {
                @Override public void run() {
                    SwingUtilities.invokeLater(toast::dispose);
                }
            }, 4000);
        });
    }

    private void scheduleAutoClear(String msg, long delayMs) {
        if (autoClearTimer != null) autoClearTimer.cancel();
        autoClearTimer = new Timer(true);
        autoClearTimer.schedule(new TimerTask() {
            @Override public void run() {
                SwingUtilities.invokeLater(() -> {
                    alertsModel.removeElement(msg);
                    if (alertsModel.isEmpty()) resetTabIcon();
                });
            }
        }, delayMs);
    }

    public void clearAll() {
        alertsModel.clear();
        resetTabIcon();
    }
}
