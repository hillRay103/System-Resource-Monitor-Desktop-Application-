package com.systemmonitor.ui;

import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.net.URL;

/**
 * IconLoader — loads icons from the resources/icons folder.
 * If an icon file is missing it returns a small colored square fallback
 * so the UI never shows broken/null icons.
 */
public class IconLoader {

    public static ImageIcon load(String name, int size) {
        URL location = IconLoader.class.getResource("/com/systemmonitor/resources/icons/" + name);
        if (location != null) {
            try {
                ImageIcon icon = new ImageIcon(location);
                Image image = icon.getImage().getScaledInstance(size, size, Image.SCALE_SMOOTH);
                return new ImageIcon(image);
            } catch (Exception e) {
                System.err.println("Failed to load icon: " + name + " - " + e.getMessage());
            }
        } else {
            System.err.println("Icon not found: /com/systemmonitor/resources/icons/" + name);
        }
        return makeFallbackIcon(name, size);
    }

    private static ImageIcon makeFallbackIcon(String name, int size) {
        BufferedImage img = new BufferedImage(size, size, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = img.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        Color bg = pickColor(name);
        g.setColor(bg);
        g.fillOval(1, 1, size - 2, size - 2);
        g.setColor(Color.WHITE);
        int fontSize = Math.max(8, size / 2);
        g.setFont(new Font("Segoe UI", Font.BOLD, fontSize));
        String letter = (name == null || name.isEmpty()) ? "?" : name.substring(0, 1).toUpperCase();
        FontMetrics fm = g.getFontMetrics();
        int x = (size - fm.stringWidth(letter)) / 2;
        int y = (size - fm.getHeight()) / 2 + fm.getAscent();
        g.drawString(letter, x, y);
        g.dispose();
        return new ImageIcon(img);
    }

    private static Color pickColor(String name) {
        if (name == null) return new Color(0x8A2BE2);
        String n = name.toLowerCase();
        if (n.startsWith("home"))      return new Color(100, 60, 200);
        if (n.startsWith("dashboard")) return new Color(80, 130, 220);
        if (n.startsWith("process"))   return new Color(60, 160, 100);
        if (n.startsWith("alert"))     return new Color(220, 80, 80);
        if (n.startsWith("log"))       return new Color(180, 130, 50);
        if (n.startsWith("disk"))      return new Color(50, 150, 180);
        if (n.startsWith("warning"))   return new Color(220, 120, 0);
        if (n.startsWith("settings"))  return new Color(100, 100, 100);
        if (n.startsWith("info"))      return new Color(30, 140, 200);
        return new Color(0x8A2BE2);
    }
}
