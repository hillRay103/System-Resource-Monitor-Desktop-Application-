package com.systemmonitor.ui;

import com.systemmonitor.cpu.CpuService;
import com.systemmonitor.disk.DiskService;
import com.systemmonitor.memory.MemoryService;
import com.systemmonitor.process.ProcessInfo;
import com.systemmonitor.process.ProcessService;
import com.systemmonitor.utils.LoggerService;
import com.systemmonitor.utils.SettingsService;
import org.jfree.chart.*;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.*;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.data.xy.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.List;

public class DashboardUI extends JFrame {

    private CpuService cpuService;
    private MemoryService memoryService;
    private DiskService diskService;
    private ProcessService processService;

    private JLabel cpuValueLabel;
    private JLabel memoryValueLabel;
    private JLabel diskValueLabel;

    private XYSeries cpuSeries;
    private XYSeries memorySeries;
    private XYSeries diskSeries;

    // single shared components (created once)
    private JTable processTable;
    private AlertsUI alertsUI;
    private JLabel statusLine;

    private JPanel cards;
    private CardLayout cardLayout;
    private Timer updateTimer;
    private double timeCounter = 0;

    // Sidebar buttons to toggle active visual
    private JButton[] sidebarButtons;

    public DashboardUI() {
        setTitle("System Resource Monitor");
        setSize(1200, 720);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
        getContentPane().setBackground(UIConstants.BG);

        cpuService = new CpuService();
        memoryService = new MemoryService();
        diskService = new DiskService();
        processService = new ProcessService();

        // create single shared components BEFORE building cards
        processTable = createProcessTable();    // single instance
    

        initHeader();
        initSidebar();
         alertsUI = new AlertsUI(sidebarButtons[3]);
        initMainDashboardCards();

        startLiveUpdates();
    }

    private void initHeader() {
        JPanel header = new JPanel(new BorderLayout());
        header.setPreferredSize(new Dimension(0, UIConstants.HEADER_HEIGHT));
        header.setBackground(UIConstants.BG);
        header.setBorder(new EmptyBorder(8, 12, 8, 12));

        JLabel title = new JLabel("System Resource Monitor");
        title.setFont(UIConstants.H1);
        title.setForeground(UIConstants.ACCENT);
        header.add(title, BorderLayout.WEST);

        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 6));
        right.setOpaque(false);

        JButton refresh = UIUtils.createHeaderButton("⟳");
        refresh.addActionListener(e -> updateDashboard());
        right.add(refresh);

        header.add(right, BorderLayout.EAST);

        add(header, BorderLayout.NORTH);
    }

    private void initSidebar() {
        JPanel sidebar = new JPanel();
        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));
        sidebar.setPreferredSize(new Dimension(UIConstants.SIDEBAR_WIDTH, 0));
        sidebar.setBackground(UIConstants.SIDEBAR_BG);
        sidebar.setBorder(new EmptyBorder(12, 8, 12, 8));

        String[] items = {"Welcome", "Dashboard", "Processes", "Alerts", "Logs", "Settings"};
        String[] iconNames = {"home.png","dashboard.png","process.png","alerts.png","logs.png","settings.png"};

        sidebarButtons = new JButton[items.length];

        for (int i = 0; i < items.length; i++) {
            Icon ic = IconLoader.load(iconNames[i], 18);
            JButton btn = UIUtils.createSidebarButton(items[i], ic);
            final String name = items[i];
            btn.addActionListener(e -> {
                showCard(name);
                setActiveSidebarButton(btn);
            });
            btn.setAlignmentX(Component.LEFT_ALIGNMENT);
            sidebar.add(btn);
            sidebar.add(Box.createVerticalStrut(8));
            sidebarButtons[i] = btn;
        }

        add(sidebar, BorderLayout.WEST);
    }

    private void setActiveSidebarButton(JButton active) {
        for (JButton b : sidebarButtons) {
            if (b == active) {
                b.setBackground(UIConstants.ACCENT_HOVER);
            } else {
                b.setBackground(UIConstants.SIDEBAR_BG);
            }
        }
    }

    private void initMainDashboardCards() {
        cardLayout = new CardLayout();
        cards = new JPanel(cardLayout);
        cards.setBackground(UIConstants.BG);

        // --- Welcome card (short & clear) ---
        JPanel welcome = new JPanel(new BorderLayout());
        welcome.setBackground(UIConstants.BG);
        JPanel center = new JPanel();
        center.setBackground(UIConstants.BG);
        center.setLayout(new BoxLayout(center, BoxLayout.Y_AXIS));
        center.setBorder(new EmptyBorder(40, 40, 40, 40));

        JLabel wTitle = new JLabel("Welcome to System Resource Monitor");
        wTitle.setFont(UIConstants.H1);
        wTitle.setForeground(UIConstants.ACCENT);
        wTitle.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel wLine = new JLabel("<html><div style='text-align:center; width:720px'>" +
                "<b>Quickly visualize CPU, Memory, Disk and Processes — in real time.</b><br>" +
                "No setup. Open the dashboard to view live metrics, alerts, and process tools." +
                "</div></html>");
        wLine.setFont(UIConstants.BODY);
        wLine.setForeground(UIConstants.MUTED_TEXT);
        wLine.setAlignmentX(Component.CENTER_ALIGNMENT);
        wLine.setBorder(new EmptyBorder(12,0,24,0));

        // feature cards row
        JPanel features = new JPanel(new GridLayout(1,4,12,12));
        features.setBackground(UIConstants.BG);
        features.setMaximumSize(new Dimension(1000,120));

        features.add(buildFeatureCard("CPU", "Live CPU usage chart", "dashboard.png"));
        features.add(buildFeatureCard("Memory", "Used / Total memory", "process.png"));
        features.add(buildFeatureCard("Disk", "Storage usage & partitions", "disk.png"));
        features.add(buildFeatureCard("Processes", "View & manage running processes", "process.png"));

        JButton open = new JButton("Open Dashboard →");
        open.setFont(UIConstants.H2);
        open.setForeground(UIConstants.TEXT);
        open.setBackground(UIConstants.ACCENT);
        open.setFocusPainted(false);
        open.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        open.setAlignmentX(Component.CENTER_ALIGNMENT);
        open.addActionListener(e -> {
            showCard("Dashboard");
            setActiveSidebarButton(sidebarButtons[1]);
        });
        // hover faster
        open.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override public void mouseEntered(java.awt.event.MouseEvent e) { open.setBackground(UIConstants.ACCENT_HOVER); }
            @Override public void mouseExited(java.awt.event.MouseEvent e) { open.setBackground(UIConstants.ACCENT); }
        });

        center.add(wTitle);
        center.add(wLine);
        center.add(features);
        center.add(Box.createVerticalStrut(18));
        center.add(open);

        welcome.add(center, BorderLayout.CENTER);
        cards.add(welcome, "Welcome");

        // Dashboard main panel
        JPanel mainPanel = buildDashboardMainPanel();
        cards.add(mainPanel, "Dashboard");

        // Processes panel - use the single shared processTable
        JPanel processesPanel = new JPanel(new BorderLayout());
        processesPanel.setBackground(UIConstants.BG);
        JScrollPane pScroll = new JScrollPane(processTable);
        UIUtils.createCleanScroll(pScroll);
        processesPanel.add(UIUtils.wrapCard("Running Processes", pScroll), BorderLayout.CENTER);
        cards.add(processesPanel, "Processes");

        // Alerts panel - use the single shared alertsUI
        JPanel alertsPanel = new JPanel(new BorderLayout());
        alertsPanel.setBackground(UIConstants.BG);
        alertsPanel.add(UIUtils.wrapCard("System Alerts", alertsUI), BorderLayout.CENTER);
        cards.add(alertsPanel, "Alerts");

        // Logs panel (same as before)
        JPanel logsPanel = new JPanel(new BorderLayout());
        logsPanel.setBackground(UIConstants.BG);
        JTextArea logsArea = new JTextArea();
        UIUtils.styleMonospaceArea(logsArea);
        JScrollPane logsScroll = new JScrollPane(logsArea);
        UIUtils.createCleanScroll(logsScroll);
        JPanel logsTop = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        logsTop.setOpaque(false);
        JButton logsRefresh = UIUtils.createHeaderButton("Refresh");
        JButton logsClear = UIUtils.createHeaderButton("Clear");
        logsRefresh.addActionListener((ActionEvent e) -> logsArea.setText(LoggerService.readLogs()));
        logsClear.addActionListener((ActionEvent e) -> { LoggerService.clearLogs(); logsArea.setText(""); });
        logsTop.add(logsRefresh);
        logsTop.add(logsClear);
        logsPanel.add(logsTop, BorderLayout.NORTH);
        logsPanel.add(UIUtils.wrapCard("Logs", logsScroll), BorderLayout.CENTER);
        cards.add(logsPanel, "Logs");

        // Settings panel - small form (reuse your code but style)
        JPanel settingsPanel = new JPanel(new BorderLayout());
        settingsPanel.setBackground(UIConstants.BG);
        JPanel form = new JPanel(new GridLayout(5,2,8,8));
        form.setBackground(UIConstants.BG);
        JLabel lblRefresh = new JLabel("Refresh interval (ms):");
        lblRefresh.setForeground(UIConstants.TEXT);
        JSpinner spRefresh = new JSpinner(new SpinnerNumberModel(SettingsService.getRefreshIntervalMs(), 200, 10000, 100));
        JLabel lblCpu = new JLabel("CPU alert %:");
        lblCpu.setForeground(UIConstants.TEXT);
        JSpinner spCpu = new JSpinner(new SpinnerNumberModel(SettingsService.getCpuAlertPercent(), 1, 100, 1));
        JLabel lblMem = new JLabel("Memory alert %:");
        lblMem.setForeground(UIConstants.TEXT);
        JSpinner spMem = new JSpinner(new SpinnerNumberModel(SettingsService.getMemoryAlertPercent(), 1, 100, 1));
        JLabel lblDisk = new JLabel("Disk alert %:");
        lblDisk.setForeground(UIConstants.TEXT);
        JSpinner spDisk = new JSpinner(new SpinnerNumberModel(SettingsService.getDiskAlertPercent(), 1, 100, 1));
        form.add(lblRefresh); form.add(spRefresh);
        form.add(lblCpu); form.add(spCpu);
        form.add(lblMem); form.add(spMem);
        form.add(lblDisk); form.add(spDisk);
        JButton save = UIUtils.createHeaderButton("Save Settings");
        save.addActionListener(e -> {
            SettingsService.setRefreshIntervalMs((Integer)spRefresh.getValue());
            SettingsService.setCpuAlertPercent((Integer)spCpu.getValue());
            SettingsService.setMemoryAlertPercent((Integer)spMem.getValue());
            SettingsService.setDiskAlertPercent((Integer)spDisk.getValue());
            SettingsService.save();
            LoggerService.log("Settings saved");
            restartTimer();
            JOptionPane.showMessageDialog(this, "Settings saved.");
        });
        JPanel saveP = new JPanel();
        saveP.setOpaque(false);
        saveP.add(save);
        settingsPanel.add(UIUtils.wrapCard("Settings", form), BorderLayout.CENTER);
        settingsPanel.add(saveP, BorderLayout.SOUTH);
        cards.add(settingsPanel, "Settings");

        add(cards, BorderLayout.CENTER);

        // auto-switch from Welcome to Dashboard after 4s
        Timer t = new Timer(4000, e -> {
            showCard("Dashboard");
            setActiveSidebarButton(sidebarButtons[1]);
        });
        t.setRepeats(false);
        t.start();
    }

    private JPanel buildDashboardMainPanel() {
        JPanel main = new JPanel(new BorderLayout(10,10));
        main.setBackground(UIConstants.BG);
        main.setBorder(new EmptyBorder(12,12,12,12));

        // top cards
        JPanel top = new JPanel(new GridLayout(1,4,12,12));
        top.setBackground(UIConstants.BG);

        cpuValueLabel = createCardLabel("--");
        memoryValueLabel = createCardLabel("--");
        diskValueLabel = createCardLabel("--");
        JLabel statusCard = createCardLabel("System Status");
        statusLine = new JLabel("Initializing...", SwingConstants.CENTER);
        statusLine.setForeground(UIConstants.MUTED_TEXT);
        statusLine.setFont(UIConstants.BODY);
        JPanel statusWrap = new JPanel(new BorderLayout());
        statusWrap.setBackground(UIConstants.CARD_BG);
        statusWrap.add(statusCard, BorderLayout.NORTH);
        statusWrap.add(statusLine, BorderLayout.CENTER);

        top.add(UIUtils.wrapCard("CPU Usage", cpuValueLabel));
        top.add(UIUtils.wrapCard("Memory Usage", memoryValueLabel));
        top.add(UIUtils.wrapCard("Disk Usage", diskValueLabel));
        top.add(statusWrap);

        main.add(top, BorderLayout.NORTH);

        // charts - give each chart panel a preferred height so nothing overlaps
        cpuSeries = new XYSeries("CPU");
        memorySeries = new XYSeries("Memory");
        diskSeries = new XYSeries("Disk");

        JPanel charts = new JPanel(new GridLayout(1,3,12,12));
        charts.setBackground(UIConstants.BG);

        ChartPanel cpuChart = createChartPanel(cpuSeries, "CPU %");
        ChartPanel memChart = createChartPanel(memorySeries, "Memory %");
        ChartPanel diskChart = createChartPanel(diskSeries, "Disk %");

        // crucial — prevent overlap by forcing preferred size (adjust height as needed)
        cpuChart.setPreferredSize(new Dimension(300, 160));
        memChart.setPreferredSize(new Dimension(300, 160));
        diskChart.setPreferredSize(new Dimension(300, 160));

        charts.add(cpuChart);
        charts.add(memChart);
        charts.add(diskChart);

        // put charts inside a container with a fixed preferred height
        JPanel chartsWrap = new JPanel(new BorderLayout());
        chartsWrap.setBackground(UIConstants.BG);
        chartsWrap.add(charts, BorderLayout.CENTER);
        chartsWrap.setPreferredSize(new Dimension(0, 180));

        main.add(chartsWrap, BorderLayout.CENTER);

        // NOTE: removed Alerts and Process table from the Dashboard to avoid overlapping
        // Alerts and Process table are now only in their own cards under the sidebar.

        return main;
    }

    private JLabel createCardLabel(String text) {
        JLabel l = new JLabel(text, SwingConstants.CENTER);
        l.setForeground(UIConstants.TEXT);
        l.setFont(UIConstants.H2);
        l.setBorder(BorderFactory.createLineBorder(UIConstants.ACCENT, 2));
        l.setOpaque(false);
        return l;
    }


    private JTable createProcessTable() {
        String[] cols = {"PID", "Name", "CPU%", "RAM%"};
        DefaultTableModel model = new DefaultTableModel(cols,0) {
            @Override public boolean isCellEditable(int row, int column) { return false; }
        };
        JTable table = new JTable(model);
        table.setRowHeight(24);
        table.setFont(UIConstants.BODY);
        table.setForeground(UIConstants.TEXT);
        table.setBackground(UIConstants.CARD_BG);
        table.setGridColor(new Color(0x333333));
        JTableHeader h = table.getTableHeader();
        h.setBackground(new Color(0x3a0b3a));
        h.setForeground(UIConstants.TEXT);
        h.setFont(UIConstants.BODY);

        // center PID and numeric columns
        DefaultTableCellRenderer center = new DefaultTableCellRenderer();
        center.setHorizontalAlignment(SwingConstants.CENTER);
        table.getColumnModel().getColumn(0).setCellRenderer(center);
        table.getColumnModel().getColumn(2).setCellRenderer(center);
        table.getColumnModel().getColumn(3).setCellRenderer(center);

        // zebra striping
        table.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override public Component getTableCellRendererComponent(JTable t, Object value, boolean isSelected, boolean hasFocus, int row, int col) {
                Component c = super.getTableCellRendererComponent(t, value, isSelected, hasFocus, row, col);
                if (isSelected) {
                    c.setBackground(new Color(0x4b2b4b));
                } else {
                    c.setBackground((row % 2 == 0) ? UIConstants.CARD_BG : new Color(0x222222));
                }
                c.setForeground(UIConstants.TEXT);
                return c;
            }
        });

        // allow row selection
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        return table;
    }

    private JPanel buildFeatureCard(String title, String subtitle, String iconName) {
        JPanel p = new JPanel(new BorderLayout(6,6));
        p.setBackground(UIConstants.CARD_BG);
        p.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
        Icon ic = IconLoader.load(iconName, 36);
        JLabel il = new JLabel(ic);
        il.setOpaque(false);
        JLabel t = new JLabel("<html><b>" + title + "</b><br><span style='font-size:11px;color:#C6BEEA'>" + subtitle + "</span></html>");
        t.setForeground(UIConstants.MUTED_TEXT);
        p.add(il, BorderLayout.WEST);
        p.add(t, BorderLayout.CENTER);
        return p;
    }
    private ChartPanel createChartPanel(XYSeries series, String title) {
    XYSeriesCollection dataset = new XYSeriesCollection(series);
    JFreeChart chart = ChartFactory.createXYLineChart(
            title, "t", "%", dataset, 
            PlotOrientation.VERTICAL, false, false, false
    );
    chart.setBackgroundPaint(UIConstants.BG);
    chart.setAntiAlias(true);

    // FIX: Change chart title color (CPU %, Memory %, Disk %)
    chart.getTitle().setPaint(UIConstants.TEXT);

    XYPlot plot = chart.getXYPlot();
    plot.setBackgroundPaint(new Color(0x201020));
    plot.setDomainGridlinePaint(new Color(0x402040));
    plot.setRangeGridlinePaint(new Color(0x402040));

    XYLineAndShapeRenderer renderer = new XYLineAndShapeRenderer(true, false);
    renderer.setSeriesPaint(0, UIConstants.TEXT);
    renderer.setSeriesStroke(0, new BasicStroke(2.4f));
    plot.setRenderer(renderer);

    NumberAxis domain = (NumberAxis) plot.getDomainAxis();
    NumberAxis range = (NumberAxis) plot.getRangeAxis();
    domain.setTickLabelPaint(UIConstants.MUTED_TEXT);
    range.setTickLabelPaint(UIConstants.MUTED_TEXT);
    domain.setLabelPaint(UIConstants.MUTED_TEXT);
    range.setLabelPaint(UIConstants.MUTED_TEXT);
    domain.setTickLabelFont(UIConstants.BODY);
    range.setTickLabelFont(UIConstants.BODY);

    ChartPanel cp = new ChartPanel(chart);
    cp.setBackground(UIConstants.CARD_BG);
    cp.setPreferredSize(new Dimension(300, 160));
    return cp;
}

    

    private void startLiveUpdates() {
        int interval = SettingsService.getRefreshIntervalMs();
        if (updateTimer != null) updateTimer.stop();
        updateTimer = new Timer(interval, e -> updateDashboard());
        updateTimer.start();
    }

    private void restartTimer() {
        if (updateTimer != null) updateTimer.stop();
        startLiveUpdates();
    }

    private void updateDashboard() {
        try {
            double cpu = cpuService.getCpuUsage();
            cpuValueLabel.setText(String.format("%.1f%%", cpu));
            cpuSeries.add(timeCounter, cpu);

            long usedMem = memoryService.getUsedMemory();
            long totalMem = memoryService.getTotalMemory();
            double memPercent = totalMem == 0 ? 0.0 : usedMem * 100.0 / totalMem;
            memoryValueLabel.setText(String.format("%.1f / %.1f GB", usedMem / 1e9, totalMem / 1e9));
            memorySeries.add(timeCounter, memPercent);

            long usedDisk = diskService.getUsedDiskSpace();
            long totalDisk = diskService.getTotalDiskSpace();
            double diskPercent = totalDisk == 0 ? 0.0 : usedDisk * 100.0 / totalDisk;
            diskValueLabel.setText(String.format("%.1f / %.1f GB", usedDisk / 1e9, totalDisk / 1e9));
            diskSeries.add(timeCounter, diskPercent);
            // ------------------ SYSTEM STATUS ------------------
        ImageIcon warningIcon = IconLoader.load("warning.png", 16);

if (cpu > SettingsService.getCpuAlertPercent() ||
    memPercent > SettingsService.getMemoryAlertPercent() ||
    diskPercent > SettingsService.getDiskAlertPercent()) {

    statusLine.setText("⚠ Check Alerts!");
    statusLine.setForeground(Color.RED);
    statusLine.setIcon(warningIcon);

} else {
    statusLine.setText("All systems normal");
    statusLine.setForeground(new Color(0, 200, 0)); // Green
    statusLine.setFont(UIConstants.H2.deriveFont(Font.BOLD));
    statusLine.setIcon(null); // no icon for normal
}

            alertsUI.clearAll();
            // CPU
if (cpu > SettingsService.getCpuAlertPercent()) {
    alertsUI.addAlert("❗ High CPU usage: " + String.format("%.1f", cpu) + "%", true); // popup triggers
} else if (cpu > SettingsService.getCpuAlertPercent() * 0.8) {
    alertsUI.addSuggestion("CPU approaching limit: " + String.format("%.1f", cpu) + "%");
}
// Memory
if (memPercent > SettingsService.getMemoryAlertPercent()) {
    alertsUI.addAlert("❗ Memory almost full: " + String.format("%.1f", memPercent) + "%", true);
} else if (memPercent > SettingsService.getMemoryAlertPercent() * 0.8) {
    alertsUI.addSuggestion("Memory approaching limit: " + String.format("%.1f", memPercent) + "%");
}
// Disk
if (diskPercent > SettingsService.getDiskAlertPercent()) {
    alertsUI.addAlert("❗ Disk nearly full: " + String.format("%.1f", diskPercent) + "%", true);
} else if (diskPercent > SettingsService.getDiskAlertPercent() * 0.8) {
    alertsUI.addSuggestion("Disk approaching limit: " + String.format("%.1f", diskPercent) + "%");
}

            // processes update - only update the shared processTable model (displayed on Processes card)
            List<ProcessInfo> plist = processService.getProcesses();
            DefaultTableModel model = (DefaultTableModel) processTable.getModel();
            model.setRowCount(0);
            for (ProcessInfo p : plist) {
                model.addRow(new Object[]{
                        p.getPid(),
                        p.getName(),
                        String.format("%.1f", p.getCpuPercent()),
                        String.format("%.1f", p.getMemoryPercent())
                });
            }

            timeCounter++;
        } catch (Throwable ex) {
            LoggerService.log("Update error: " + ex.getMessage());
        }
    }

    private void showCard(String name) {
        if ("Logs".equals(name)) {
            // refresh logs (iterate through components and fill textareas)
            SwingUtilities.invokeLater(() -> {
                for (Component comp : cards.getComponents()) {
                    if (comp instanceof JPanel) {
                        JPanel p = (JPanel) comp;
                        for (Component child : p.getComponents()) {
                            if (child instanceof JScrollPane) {
                                JScrollPane sp = (JScrollPane) child;
                                JViewport v = sp.getViewport();
                                if (v.getView() instanceof JTextArea) {
                                    JTextArea ta = (JTextArea) v.getView();
                                    ta.setText(LoggerService.readLogs());
                                }
                            }
                        }
                    }
                }
            });
        }
        cardLayout.show(cards, name);
    }
}
