package com.systemmonitor.ui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class UIUtils {

    // Create sidebar-style button (icon can be null)
    public static JButton createSidebarButton(String text, Icon icon) {
        JButton btn = new JButton(text, icon);
        btn.setHorizontalAlignment(SwingConstants.LEFT);
        btn.setForeground(UIConstants.TEXT);
        btn.setBackground(UIConstants.SIDEBAR_BG);
        btn.setFocusPainted(false);
        btn.setFont(UIConstants.BODY);
        btn.setBorder(BorderFactory.createEmptyBorder(12, 16, 12, 16));
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        btn.addMouseListener(new MouseAdapter() {
            @Override public void mouseEntered(MouseEvent e) {
                btn.setBackground(UIConstants.ACCENT);
            }
            @Override public void mouseExited(MouseEvent e) {
                btn.setBackground(UIConstants.SIDEBAR_BG);
            }
        });
        return btn;
    }

    // Create a compact header button (round-ish)
    public static JButton createHeaderButton(String text) {
        JButton btn = new JButton(text);
        btn.setForeground(UIConstants.TEXT);
        btn.setBackground(UIConstants.ACCENT);
        btn.setFocusPainted(false);
        btn.setFont(UIConstants.BODY);
        btn.setBorder(BorderFactory.createEmptyBorder(6,10,6,10));
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        btn.addMouseListener(new MouseAdapter() {
            @Override public void mouseEntered(MouseEvent e) { btn.setBackground(UIConstants.ACCENT_HOVER); }
            @Override public void mouseExited(MouseEvent e) { btn.setBackground(UIConstants.ACCENT); }
        });
        return btn;
    }

    // Wrap a component into a card with title
    public static JPanel wrapCard(String title, JComponent comp) {
        JPanel p = new JPanel(new BorderLayout(8,8));
        p.setBackground(UIConstants.CARD_BG);
        p.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));

        JLabel lbl = new JLabel(title);
        lbl.setFont(UIConstants.H2);
        lbl.setForeground(UIConstants.ACCENT);

        p.add(lbl, BorderLayout.NORTH);
        comp.setBackground(UIConstants.CARD_BG);
        p.add(comp, BorderLayout.CENTER);

        return p;
    }

    // Style JTextArea for logs/alerts
    public static void styleMonospaceArea(JTextArea area) {
        area.setFont(UIConstants.MONO);
        area.setForeground(UIConstants.MUTED_TEXT);
        area.setBackground(new Color(0x151515));
        area.setEditable(false);
    }

    // --------------------------- NEW CLEAN SCROLL METHOD ---------------------------

    // Create a clean, styled scroll panel for tables, text areas, panels
    public static JScrollPane createCleanScroll(JComponent comp) {
        JScrollPane scroll = new JScrollPane(comp);
        scroll.setBorder(BorderFactory.createEmptyBorder());
        scroll.getViewport().setBackground(UIConstants.CARD_BG);
        scroll.setBackground(UIConstants.CARD_BG);

        scroll.setViewportBorder(null);

        JScrollBar vBar = scroll.getVerticalScrollBar();
        JScrollBar hBar = scroll.getHorizontalScrollBar();

        vBar.setUI(new CustomScrollBarUI());
        hBar.setUI(new CustomScrollBarUI());

        vBar.setUnitIncrement(16);
        hBar.setUnitIncrement(16);

        return scroll;
    }

    // Minimalist dark scrollbar UI
    static class CustomScrollBarUI extends javax.swing.plaf.basic.BasicScrollBarUI {
        @Override
        protected void configureScrollBarColors() {
            this.thumbColor = UIConstants.ACCENT;
            this.trackColor = UIConstants.CARD_BG;
        }

        @Override
        protected JButton createDecreaseButton(int orientation) {
            return createZeroButton();
        }

        @Override
        protected JButton createIncreaseButton(int orientation) {
            return createZeroButton();
        }

        private JButton createZeroButton() {
            JButton btn = new JButton();
            btn.setPreferredSize(new Dimension(0, 0));
            btn.setVisible(false);
            return btn;
        }
    }
}
