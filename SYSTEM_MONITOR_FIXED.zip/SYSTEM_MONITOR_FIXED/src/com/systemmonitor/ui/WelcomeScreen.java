package com.systemmonitor.ui;

import javax.swing.*;
import java.awt.*;

public class WelcomeScreen extends JWindow {

    public WelcomeScreen() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(new Color(20, 20, 20));

        // Center panel for title and subtitle
        JPanel centerPanel = new JPanel();
        centerPanel.setBackground(new Color(20, 20, 20));
        centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));

        // Title
        JLabel title = new JLabel("System Resource Monitor", SwingConstants.CENTER);
        title.setForeground(new Color(180, 140, 255));
        title.setFont(new Font("Segoe UI", Font.BOLD, 32));
        title.setAlignmentX(Component.CENTER_ALIGNMENT);

        // Subtitle
        JLabel sub = new JLabel("Monitoring your system health in real-time...", SwingConstants.CENTER);
        sub.setForeground(new Color(200, 200, 200));
        sub.setFont(new Font("Segoe UI", Font.PLAIN, 14)); // lighter size
        sub.setAlignmentX(Component.CENTER_ALIGNMENT);

        // Add title and subtitle vertically
        centerPanel.add(Box.createVerticalGlue());
        centerPanel.add(title);
        centerPanel.add(Box.createRigidArea(new Dimension(0, 8))); // small spacing
        centerPanel.add(sub);
        centerPanel.add(Box.createVerticalGlue());

        panel.add(centerPanel, BorderLayout.CENTER);

        // Bottom-right credit
        JLabel credit = new JLabel(
    "<html>Presented by &lt;" +
    "<span style='color:#B388FF;'>KHADIJAH NAVEED</span>&gt;</html>"
    );
        credit.setForeground(new Color(180, 140, 255));
        credit.setFont(new Font("Segoe UI", Font.ITALIC, 12));

        JPanel creditPanel = new JPanel(new BorderLayout());
        creditPanel.setBackground(new Color(20, 20, 20));
        creditPanel.setBorder(BorderFactory.createEmptyBorder(0, 0, 10, 10));
        creditPanel.add(credit, BorderLayout.EAST);

        panel.add(creditPanel, BorderLayout.SOUTH);

        getContentPane().add(panel);
        setSize(600, 300);
        setLocationRelativeTo(null);
    }

       

    public void showFor2Seconds() {
        setVisible(true);
        try {
            Thread.sleep(3000);
        } catch (Exception ignored) {}
        setVisible(false);
    }
}
