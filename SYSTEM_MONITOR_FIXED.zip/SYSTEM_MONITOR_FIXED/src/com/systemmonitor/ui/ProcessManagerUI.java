package com.systemmonitor.ui;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;
import com.systemmonitor.process.ProcessInfo;
import com.systemmonitor.process.ProcessService;

public class ProcessManagerUI extends JPanel {

    private JTable processTable;
    private DefaultTableModel tableModel;
    private JTextField searchField;
    private JLabel warningLabel;

    private final ProcessService processService = new ProcessService();

    public ProcessManagerUI() {
        setLayout(new BorderLayout());
        setBackground(Color.BLACK);

        initTableWithSearch();
        initWarningPanel();
        loadProcesses();
    }

    // -------- TABLE WITH TITLE + SEARCH --------
    private void initTableWithSearch() {
        String[] cols = {"PID", "Process Name", "CPU %", "Memory %"};
        tableModel = new DefaultTableModel(cols, 0);

        processTable = new JTable(tableModel);
        processTable.setBackground(new Color(30, 30, 30));
        processTable.setForeground(Color.WHITE);
        processTable.setGridColor(new Color(120, 50, 255));
        processTable.setFont(new Font("Segoe UI", Font.PLAIN, 14));

        JScrollPane scroll = new JScrollPane(processTable);
        scroll.setBorder(BorderFactory.createLineBorder(new Color(120, 50, 255)));

        // -------- TOP PANEL (Title + Search + Refresh) --------
        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setBackground(Color.BLACK);
        topPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JLabel title = new JLabel("Running Processes");
        title.setForeground(new Color(180, 150, 255));
        title.setFont(new Font("Segoe UI", Font.BOLD, 20));

        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 5, 0));
        searchPanel.setBackground(Color.BLACK);

        searchField = new JTextField(15);
        JButton searchBtn = new JButton("Search");
        JButton refreshBtn = new JButton("Refresh");

        styleButton(searchBtn);
        styleButton(refreshBtn);

        searchBtn.addActionListener(e -> searchProcess());
        refreshBtn.addActionListener(e -> loadProcesses());

        searchPanel.add(searchField);
        searchPanel.add(searchBtn);
        searchPanel.add(refreshBtn);

        topPanel.add(title, BorderLayout.WEST);
        topPanel.add(searchPanel, BorderLayout.EAST);

        // -------- MAIN PANEL --------
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.add(topPanel, BorderLayout.NORTH);
        mainPanel.add(scroll, BorderLayout.CENTER);

        add(mainPanel, BorderLayout.CENTER);
    }

    // -------- WARNING PANEL --------
    private void initWarningPanel() {
        JPanel warningPanel = new JPanel(new BorderLayout());
        warningPanel.setBackground(new Color(25, 15, 40));
        warningPanel.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));

        warningLabel = new JLabel(" ");
        warningLabel.setForeground(new Color(255, 200, 100));
        warningLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));

        warningPanel.add(warningLabel, BorderLayout.CENTER);
        add(warningPanel, BorderLayout.SOUTH);
    }

    // -------- LOAD DATA --------
    private void loadProcesses() {
        tableModel.setRowCount(0);
        warningLabel.setText(" ");

        List<ProcessInfo> list = processService.getProcesses();
        for (ProcessInfo p : list) {
            tableModel.addRow(new Object[]{
                    p.getPid(),
                    p.getName(),
                    String.format("%.1f", p.getCpuPercent()),
                    String.format("%.1f", p.getMemoryPercent())
            });
        }
    }

    // -------- SEARCH LOGIC --------
    private void searchProcess() {
        String key = searchField.getText().toLowerCase().trim();
        tableModel.setRowCount(0);
        warningLabel.setText(" ");

        for (ProcessInfo p : processService.getProcesses()) {
            if (p.getName().toLowerCase().contains(key)) {
                tableModel.addRow(new Object[]{
                        p.getPid(),
                        p.getName(),
                        String.format("%.1f", p.getCpuPercent()),
                        String.format("%.1f", p.getMemoryPercent())
                });

                if (p.getMemoryPercent() > 25 && p.getCpuPercent() < 2) {
                    warningLabel.setText(
                            "⚠ Process '" + p.getName() +
                                    "' is using high memory while idle. Consider closing it if not needed."
                    );
                }
            }
        }
    }

    // -------- BUTTON STYLE --------
    private void styleButton(JButton btn) {
        btn.setBackground(new Color(120, 70, 180));
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createEmptyBorder(8, 16, 8, 16));
    }
}
