package com.systemmonitor;

import com.systemmonitor.ui.DashboardUI;
import com.systemmonitor.ui.WelcomeScreen;

public class Main {
    public static void main(String[] args) {
        WelcomeScreen splash = new WelcomeScreen();
        splash.showFor2Seconds(); 


        javax.swing.SwingUtilities.invokeLater(() -> {
            DashboardUI ui = new DashboardUI();
            ui.setVisible(true);
        });

    }
}
