package com.systemmonitor.cpu;
import com.sun.management.OperatingSystemMXBean;
import java.lang.management.ManagementFactory;
import com.systemmonitor.utils.SettingsService;

public class CpuService {

    private OperatingSystemMXBean osBean;

    public CpuService() {
        osBean = (OperatingSystemMXBean) ManagementFactory.getOperatingSystemMXBean();
    }

    
    public double getCpuUsage() {
        double cpuLoad = osBean.getCpuLoad();
        if (cpuLoad < 0) return 0;
        return cpuLoad * 100.0;
    }

    
    public boolean isCpuOverloaded() {
        return getCpuUsage() >= SettingsService.getCpuAlertPercent();
    }

    
    public double getCpuThreshold() {
        return SettingsService.getCpuAlertPercent();
    }

    
    public double getCpu() {
        return getCpuUsage();
    }
}
